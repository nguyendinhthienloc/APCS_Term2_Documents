// #include <stdio.h>


// //PROBLEM 1
// int combine(){
//     int x=0x89ABCDEF;
//     int y=0x76543210;
//     return (x&0x000000FF|y&~0x000000FF); 
// }

// int main(void) {
//     int ans = combine();
//     printf("ans = %d (0x%X)\n", ans, ans);
//     return 0;
// }

// //PROBLEM 2
// unsigned replace_byte(unsigned x, int i, unsigned char b) {
//     unsigned shift = i << 3;           // i * 8 bits
//     unsigned mask  = 0xFFu << shift;   // target byte mask
//     return (x & ~mask) | ((unsigned)b << shift);
// }

// /* Define TEST_REPLACE_BYTE when you want to compile this test main.
//    This avoids duplicate main() if other problems also define main(). */

// int main(void) {
//     unsigned x, res;

//     x = 0x12345678;
//     res = replace_byte(x, 0, 0xAB);
//     printf("replace_byte(0x%08X, %d, 0x%02X) = 0x%08X\n", x, 0, 0xAB, res);

//     res = replace_byte(x, 1, 0xFF);
//     printf("replace_byte(0x%08X, %d, 0x%02X) = 0x%08X\n", x, 1, 0xFF, res);

//     res = replace_byte(x, 3, 0x00);
//     printf("replace_byte(0x%08X, %d, 0x%02X) = 0x%08X\n", x, 3, 0x00, res);

//     x = 0x89ABCDEF;
//     res = replace_byte(x, 2, 0x12);
//     printf("replace_byte(0x%08X, %d, 0x%02X) = 0x%08X\n", x, 2, 0x12, res);

//     return 0;
// }


// //PROBLEM 3
// #include <stdio.h>

// /* A. Any bit of x equals 1 */
// int any_bit_one(int x) {
//     return !!x;
// }

// /* B. Any bit of x equals 0 */
// int any_bit_zero(int x) {
//     return !!~x;
// }

// /* C. Any bit in the least significant byte equals 1 */
// int any_bit_one_LSB(int x) {
//     return !!(x & 0xFF);
// }

// /* D. Any bit in the most significant byte equals 0 */
// int any_bit_zero_MSB(int x) {
//     return !!(~(x >> 24) & 0xFF);
// }

// /* Test all functions */
// int main(void) {
//     int test_values[] = {
//         0x00000000,  // all zeros
//         0xFFFFFFFF,  // all ones
//         0x00FF00FF,  // mixed pattern
//         0x12345678,  // random
//         0xFF000000,  // only MSB full of 1s
//         0x000000FF   // only LSB full of 1s
//     };

//     int n = sizeof(test_values) / sizeof(test_values[0]);
//     for (int i = 0; i < n; i++) {
//         int x = test_values[i];
//         printf("x = 0x%08X\n", x);
//         printf(" A. any_bit_one(x)       = %d\n", any_bit_one(x));
//         printf(" B. any_bit_zero(x)      = %d\n", any_bit_zero(x));
//         printf(" C. any_bit_one_LSB(x)   = %d\n", any_bit_one_LSB(x));
//         printf(" D. any_bit_zero_MSB(x)  = %d\n", any_bit_zero_MSB(x));
//         printf("---------------------------------\n");
//     }

//     return 0;
// }


// //PROBLEM 4
// int any_odd_one(unsigned x) {
//     unsigned mask = 0xAAAAAAAA;
//     return !!(x & mask);
// }

// int main(void) {
//     unsigned test_values[] = {
//         0x0,          // all zeros → 0
//         0x1,          // bit 0 set (even) → 0
//         0x2,          // bit 1 set (odd)  → 1
//         0xAAAAAAAA,   // all odd bits set → 1
//         0x55555555,   // all even bits set → 0
//         0x80000000,   // bit 31 (odd) set → 1
//     };

//     for (int i = 0; i < 6; i++) {
//         printf("x = 0x%08X --> any_odd_one = %d\n", test_values[i], any_odd_one(test_values[i]));
//     }

//     return 0;
// }


// //PROBLEM 5

// int lower_one_mask(int n) {
//     // Compute the mask with n least significant bits set to 1
//     // Works correctly even when n = 32
//     return (unsigned)(-1) >> ((sizeof(int) << 3) - n);
// }

// int main(void) {
//     int test_values[] = {1, 6, 8, 17, 31, 32};
//     int n = sizeof(test_values) / sizeof(test_values[0]);

//     for (int i = 0; i < n; i++) {
//         int mask = lower_one_mask(test_values[i]);
//         printf("n = %2d --> mask = 0x%08X\n", test_values[i], mask);
//     }

//     return 0;
// }

// //PROBLEM 6
// #include <limits.h>
// /* saturating add: add x+y; if overflow positive -> INT_MAX; if negative overflow -> INT_MIN */
// int sat_add(int x, int y) {
//     int sum = x + y;
//     int sx = x >> 31;
//     int sy = y >> 31;
//     int ss = sum >> 31;
//     /* overflow occurs when x and y have same sign and sum has different sign */
//     int overflow = (~(sx ^ sy)) & (sx ^ ss); /* 1..0.. mask sign-bit style */
//     /* build masks */
//     int pos_over = (~sum >> 31) & overflow; /* positive overflow when sign(sum) == 0 but overflow==1;
//                                                 using bit tricks: when overflow==1 and sx==0 => pos overflow */
//     int neg_over = (sum >> 31) & overflow;  /* negative overflow when sign(sum) == 1 and overflow==1 */
//     /* select saturated values */
//     int tmax = INT_MAX;
//     int tmin = INT_MIN;
//     /* If positive overflow -> tmax; if negative overflow -> tmin; else sum */
//     /* Build selectors: overflow_mask is either all ones or zeros - easier to use conditional-free selection */
//     /* Simpler approach using ternary-like masks constructed from overflow and sx: */
//     int is_over = !!overflow;
//     if (!is_over) return sum;
//     /* Determine direction by sign of x (or y) */
//     return (sx == 0) ? tmax : tmin;
// }

// int main(void) {
//     int tests[][2] = {
//         {0x10000000, 0x10000000},
//         {INT_MAX, 1},
//         {INT_MIN, -1},
//         {12345, 67890},
//         {-2000000000, -2000000000}
//     };
//     for (int i = 0; i < 5; ++i) {
//         int x = tests[i][0], y = tests[i][1];
//         printf("x= %d, y= %d -> sat_add = %d\n", x, y, sat_add(x, y));
//     }
//     return 0;
// }

// //PROBLEM 7

// /* Example minimal forms */
// int mul_by_17(int x) { return (x << 4) + x; }        /* 17 = 16 + 1 */
// int mul_by_neg7(int x) { return -((x << 3) - x); }   /* -7 = -(8 - 1) */
// int mul_by_60(int x) { return (x << 6) - (x << 2); } /* 60 = 64 - 4 */
// int mul_by_neg112(int x) { return -((x << 7) - (x << 4)); } /* -112 = -(128 - 16) */

// int main(void) {
//     int v = 5;
//     printf("v = %d, *17 = %d, *(-7) = %d, *60 = %d, *(-112) = %d\n",
//            v, mul_by_17(v), mul_by_neg7(v), mul_by_60(v), mul_by_neg112(v));
//     return 0;
// }

// // //PROBLEM 8
// #include <stdio.h>

// /* compute (3*x)/4 with correct truncation toward zero */
// int three_fourths(int x) {
//     return ((x << 1) + x + ((x >> 31) & 3)) >> 2;
// }

// int main(void) {
//     int tests[] = {1, 4, -1, -5, 100, -100};
//     for (int i = 0; i < (int)(sizeof(tests)/sizeof(tests[0])); ++i) {
//         int x = tests[i];
//         printf("x = %4d -> (3*x)/4 = %d\n", x, three_fourths(x));
//     }
//     return 0;
// }

// //PROBLEM 8

// /* compute (3*x)/4 with correct truncation toward zero */
// int three_fourths(int x) {
//     return ((x << 1) + x + ((x >> 31) & 3)) >> 2;
// }

// int main(void) {
//     int tests[] = {1, 4, -1, -5, 100, -100};
//     for (int i = 0; i < (int)(sizeof(tests)/sizeof(tests[0])); ++i) {
//         int x = tests[i];
//         printf("x = %4d -> (3*x)/4 = %d\n", x, three_fourths(x));
//     }
//     return 0;
// }

// //PROBLEM 9
// /* A: 1^(w-k) 0^k  -> (~0 << k) */
// unsigned pattern_A(int k) {
//     return (~0u) << k;
// }

// /* B: 0^(w-k-j) 1^k 0^j -> ((1<<k)-1) << j
//    use unsigned safe version via all-ones shift */
// unsigned pattern_B(int k, int j) {
//     unsigned ones_k = ((unsigned)(-1) >> (32 - k)); /* k ones */
//     return ones_k << j;
// }

// int main(void) {
//     printf("A k=8  -> 0x%08X\n", pattern_A(8));
//     printf("A k=16 -> 0x%08X\n", pattern_A(16));
//     printf("B k=5 j=3 -> 0x%08X\n", pattern_B(5,3));
//     printf("B k=12 j=4 -> 0x%08X\n", pattern_B(12,4));
//     return 0;
// }

// //PROBLEM 10
// /* return mask with only leftmost 1-bit of x; 0 if x==0 */
// unsigned leftmost_one(unsigned x) {
//     if (x == 0) return 0;
//     x |= x >> 1;
//     x |= x >> 2;
//     x |= x >> 4;
//     x |= x >> 8;
//     x |= x >> 16;
//     return x & ~(x >> 1);
// }

// int main(void) {
//     unsigned tests[] = {0u, 0x1u, 0xFF00u, 0x12345678u, 0x80000000u};
//     int n = sizeof(tests)/sizeof(tests[0]);
//     for (int i = 0; i < n; ++i)
//         printf("x = 0x%08X -> leftmost_one = 0x%08X\n", tests[i], leftmost_one(tests[i]));
//     return 0;
// }

// //PROBLEM 11

// /* return 1 if x has odd number of 1 bits, else 0 */
// int bit_parity(unsigned x) {
//     x ^= x >> 16;
//     x ^= x >> 8;
//     x ^= x >> 4;
//     x ^= x >> 2;
//     x ^= x >> 1;
//     return x & 1;
// }

// int main(void) {
//     unsigned tests[] = {0u, 1u, 3u, 0xF0F0F0F0u, 0xAAAAAAAAu, 0x7FFFFFFFu};
//     int n = sizeof(tests)/sizeof(tests[0]);
//     for (int i = 0; i < n; ++i)
//         printf("x = 0x%08X -> parity = %d\n", tests[i], bit_parity(tests[i]));
//     return 0;
// }

