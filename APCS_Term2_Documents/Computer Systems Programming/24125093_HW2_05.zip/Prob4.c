#include <stdio.h>
typedef unsigned float_bits;

float_bits floatTimes2(float_bits f) {
    unsigned sign = f >> 31;
    unsigned exp = (f >> 23) & 0xFF; //Get exponent
    unsigned frac = f & 0x7FFFFF;    //Get fraction (the last 23 bits)
    //0x7FFFFF = 0000 0000 0111 1111 1111 1111 1111 1111 
    if (exp == 0xFF) {                // NaN or ±∞
        return f;
    } else if (exp == 0) {            // Denormalized
        frac = frac << 1;              // multiply fraction by 2 by left shifting
        if (frac & 0x800000) {        // If after shifting, the leading bit is 1, it becomes normalized
            exp = 1;
            frac = frac & 0x7FFFFF; // Clear the leading bit and get the new fraction
        }
    } else {                          // Normalized
        exp += 1;
        if (exp == 0xFF)              // If after adding 1, exponent becomes all 1s, it becomes ±∞
            frac = 0;
    }

    return (sign << 31) | (exp << 23) | frac; //Reassemble the float bits using bitwise OR
}

int main(void) { //Written by ChatGPT for testing
    float testVals[] = { 0.0, -0.0, 1.0, -1.0, 2.5, 1e-40, 3.4e38 };
    int n = sizeof(testVals) / sizeof(testVals[0]);
    
    printf("%-12s %-12s %-12s %-12s\n", "Input(Dec)", "Input(Hex)", "Result(Dec)", "Result(Hex)");
    printf("------------------------------------------------------------\n");

    for (int i = 0; i < n; i++) {
        float x = testVals[i];
        unsigned bits = *(unsigned *)&x;
        unsigned resultBits = floatTimes2(bits);
        float result = *(float *)&resultBits;

        printf("%-12.5g  0x%08X   %-12.5g  0x%08X\n",
               x, bits, result, resultBits);
    }
    return 0;
}