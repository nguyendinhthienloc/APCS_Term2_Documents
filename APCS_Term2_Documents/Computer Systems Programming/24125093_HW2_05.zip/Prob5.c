/*
 * Full C program to test the float_f2i function.
 *
 * This includes:
 * 1. The required typedef.
 * 2. A helper union to convert float -> float_bits for testing.
 * 3. The float_f2i function implementation.
 * 4. A main() function with test cases.
 *
 * Compile with: gcc float_f2i_test.c -o test -lm
 * (You need -lm to link the math library for INFINITY and NAN)
 */

#include <stdio.h>
#include <math.h> // For INFINITY and NAN

// --- Required by the problem ---
typedef unsigned float_bits;


/*
 * Compute (int) f.
 * If conversion causes overflow or f is NaN, return 0x80000000
 */
int float_f2i(float_bits f) {
    
    // 1. Parse the bit-level representation
    unsigned sign = (f >> 31);
    unsigned exp_field = (f >> 23) & 0xFF;
    unsigned frac = (f & 0x7FFFFF);

    // 2. Handle Case 1: NaN or Infinity (exp_field == 0xFF)
    if (exp_field == 0xFF) {
        return 0x80000000;
    }

    // 3. Handle Case 2: Magnitude < 1.0 (Zero, Denorm, or frac < 1)
    // E = exp_field - 127. If E < 0, then exp_field < 127.
    if (exp_field < 127) {
        return 0;
    }
    
    // 4. Handle Case 3: Overflow (Magnitude >= 2^31)
    // E = exp_field - 127. If E >= 31, then exp_field >= 158.
    //
    // Note: This also correctly handles 0xCF000000, which is -2^31 (INT_MIN).
    // The prompt says to return 0x80000000 for overflow, and INT_MIN
    // *is* 0x80000000, so this rule works for both.
    if (exp_field >= 158) {
        return 0x80000000;
    }

    // 5. Handle Case 4: Normalized numbers that fit
    // 127 <= exp_field <= 157
    
    // Calculate E and the full significand (with implicit 1)
    int E = exp_field - 127;
    unsigned significand = frac | 0x800000; // 0x800000 is 1 << 23
    
    int result;

    if (E < 23) {
        // The binary point is inside the 23 fraction bits.
        // Shift right to truncate the fractional part.
        // This implements round-toward-zero.
        result = significand >> (23 - E);
    } else {
        // The binary point is at or after the 23 fraction bits.
        // Shift left to get the full integer value.
        result = significand << (E - 23);
    }

    // Apply the sign
    if (sign == 1) {
        return -result;
    } else {
        return result;
    }
}


// --- Test Harness Code (Written by Gemini) ---

// Union helper to convert float to bits
typedef union {
    float f;
    unsigned u;
} float_union;

// Helper function to get bits from a float
float_bits f2u(float f_val) {
    float_union un;
    un.f = f_val;
    return un.u;
}

int main() {
    // Array of test cases
    float tests[] = {
        // Case 1: NaN / Infinity
        NAN,
        INFINITY,
        -INFINITY,

        // Case 2: Magnitude < 1.0 (should be 0)
        0.0f,
        -0.0f,
        0.5f,
        -0.5f,
        0.99999f,
        -0.99999f,
        1.0e-40, // Denormalized

        // Case 4: Normal "in-range" numbers (test rounding)
        1.0f,
        -1.0f,
        1.2f,
        1.7f,
        -1.2f,
        -1.7f,
        12345.678f,
        -12345.678f,

        // Case 3 & 4: Edge of range / Overflow
        2147483520.0f,  // Largest float representable < 2^31 - 128
        -2147483520.0f,
        
        // This float literal is rounded by the compiler to 2147483648.0f
        // which is 2^31, so it IS an overflow.
        2147483647.0f, 
        
        // This is -2^31, which is INT_MIN. Should return 0x80000000
        -2147483648.0f, 
        
        // Overflow
        -2147483900.0f, // Clearly < INT_MIN
        3.4e38,         // FLT_MAX
        -3.4e38         // -FLT_MAX
    };

    int num_tests = sizeof(tests) / sizeof(tests[0]);

    printf("--- Testing float_f2i ---\n");
    printf("Special overflow return value: 0x%08X\n\n", 0x80000000);

    for (int i = 0; i < num_tests; i++) {
        float f_val = tests[i];
        float_bits f_bits = f2u(f_val);
        
        int my_result = float_f2i(f_bits);
        int expected_result = (int)f_val;

        // On x86, (int)NAN and (int)INFINITY also produce 0x80000000
        // so this comparison should work.
        
        printf("Test %2d: %-15.8g | Hex: 0x%08X | My f2i: %-12d | Expected (int): %-12d\n", 
               i, f_val, f_bits, my_result, expected_result);
    }

    return 0;
}
